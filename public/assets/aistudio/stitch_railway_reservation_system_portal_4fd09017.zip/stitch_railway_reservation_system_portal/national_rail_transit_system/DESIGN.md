---
name: National Rail Transit System
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d5e3fd'
  on-surface: '#0d1c2f'
  on-surface-variant: '#44474f'
  inverse-surface: '#233144'
  inverse-on-surface: '#ebf1ff'
  outline: '#747780'
  outline-variant: '#c4c6d0'
  surface-tint: '#465e8e'
  primary: '#00173b'
  on-primary: '#ffffff'
  primary-container: '#0f2c59'
  on-primary-container: '#7c94c8'
  inverse-primary: '#aec7fd'
  secondary: '#b6191a'
  on-secondary: '#ffffff'
  secondary-container: '#d9352f'
  on-secondary-container: '#fffbff'
  tertiary: '#001e08'
  on-tertiary: '#ffffff'
  tertiary-container: '#003514'
  on-tertiary-container: '#45a75f'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#aec7fd'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#2d4674'
  secondary-fixed: '#ffdad6'
  secondary-fixed-dim: '#ffb4ab'
  on-secondary-fixed: '#410002'
  on-secondary-fixed-variant: '#93000b'
  tertiary-fixed: '#95f8a7'
  tertiary-fixed-dim: '#79db8d'
  on-tertiary-fixed: '#00210a'
  on-tertiary-fixed-variant: '#005323'
  background: '#f8f9ff'
  on-background: '#0d1c2f'
  surface-variant: '#d5e3fd'
typography:
  headline-xl:
    fontFamily: IBM Plex Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-lg:
    fontFamily: IBM Plex Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
  headline-md:
    fontFamily: IBM Plex Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  headline-sm:
    fontFamily: IBM Plex Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
  body-lg:
    fontFamily: IBM Plex Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 22px
  body-md:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  body-sm:
    fontFamily: IBM Plex Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: IBM Plex Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: IBM Plex Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.06em
  data-mono:
    fontFamily: IBM Plex Sans
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 0.75rem
  gutter-lg: 1rem
  margin: 1rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system delivers an authentic, high-density, utilitarian interface engineered for mission-critical national rail ticketing and timetable operations. Grounded in bureaucratic precision, functional clarity, and institutional reliability, the system prioritizes rapid data retrieval, legibility under varied hardware/network constraints, and zero visual ambiguity.

The aesthetic fuses **Utilitarian Corporate** with **Civic Infrastructure Functionalism**. It avoids modern startup clichés—no decorative gradients, no translucent frosted glass, no floating pill cards with illustrative emojis, and no exaggerated dropshadows. Surfaces are crisp, information hierarchy is immediate, and status indicators mirror real-world rail classification boards: strict, tabular, and decisive.

## Colors

The palette directly references national railway signage and structural public utilities:

- **Primary (`#0F2C59` - Railway Deep Navy):** Represents institutional authority, security, and permanence. Used for top headers, navigational bars, dominant action elements, and key structural groupings.
- **Secondary (`#B91C1C` - Rail Crimson):** Used for critical reservation actions (e.g., "Book Now"), quota highlights, alerts, and waiting-list indicators.
- **Tertiary (`#15803D` - Operational Green):** Dedicated strictly to positive status markers: confirmed seat availability (`AVL`), on-time schedule indicators, and successful ticket verification.
- **Neutral (`#334155` - Slate Charcoal):** Applied for high-contrast, fatigue-free body typography against clean neutral canvas surfaces (`#F8FAFC`).

### Operational Status Badges (Semantic Utility Colors)
- **Available (`AVL`):** Text `#15803D`, Surface `#DCFCE7`, Border `#86EFAC`.
- **Reservation Against Cancellation (`RAC`):** Text `#B45309`, Surface `#FEF3C7`, Border `#FDE68A`.
- **Waitlist (`WL` / `PQWL` / `RLWL`):** Text `#B91C1C`, Surface `#FEE2E2`, Border `#FECACA`.
- **Tatkal / Premium (`TAT`):** Text `#1E40AF`, Surface `#DBEAFE`, Border `#BFDBFE`.
- **Divider & Panel Borders:** `#CBD5E1` and `#E2E8F0` for clean, unambiguous grid partitions.

## Typography

The type system runs on **IBM Plex Sans**, an open-source grotesque designed with industrial rigour and clear letterforms. 

### Critical Rules
- **Tabular Figures (`tnum`):** All numerical readouts—including 5-digit train numbers (e.g., `12301`), station codes (`NDLS`, `HWH`, `CSMT`, `SBC`), 24-hour timestamps (`06:05`, `22:45`), PNR codes, coach berth mappings (`B4-32 MB`), and fares (`₹1,845`)—must explicitly enforce `font-feature-settings: "tnum" 1, "zero" 1`.
- **Station Codes:** Upper case `label-lg` or `headline-sm` with slight tracking for unmistakable legibility on small displays.
- **High Densities:** Line-heights are tightly budgeted between 1.25x and 1.45x to allow maximum visibility of schedules without excessive vertical scrolling.

## Layout & Spacing

This system runs on a strict **8px baseline rhythm** with a nested **4px micro-increment** for dense components such as timetable matrices, berth selectors, and seat-inventory cells.

### Grid & Breakpoints
- **Desktop (≥ 1280px):** Fixed-fluid container capped at `1280px` max-width to maintain structured scan paths. 12-column layout with `gutter-lg` (`16px`) and `margin-lg` (`32px`).
- **Tablet (768px – 1279px):** 8-column layout with `gutter` (`12px`) and `margin` (`16px`). Table columns collapse into multi-tier row groups.
- **Mobile (< 768px):** 4-column layout. Forms collapse to full-width stacked rows; route progress lines convert from horizontal milestones to compact vertical timelines.

Horizontal scanning lines must align with zero surplus padding. Structural panels rely on high-density row heights (standard desktop table rows: 36px–40px; compact timetable matrices: 28px).

## Elevation & Depth

This system intentionally rejects layered shadows, diffuse ambient glows, and floating 3D elevations. Instead, depth and visual priority are articulated through **structural borders and planar contrast**:

- **Layer 0 (Canvas Base):** Ground color `#F8FAFC`.
- **Layer 1 (Containers, Data Cards, Form Strips):** Solid `#FFFFFF` bound by crisp 1px borders (`#CBD5E1`).
- **Layer 2 (Table Headers, Active Coach Tabs, Modals):** Accent panels utilizing `#F1F5F9` or full primary navy `#0F2C59` with reverse white text.
- **Focus / State Ring:** Direct `2px solid #0F2C59` with zero offset to guarantee keyboard navigation compliance in ticketing kiosks and workstation counters.
- **Shadows:** Restricted strictly to floating autocomplete menus and critical confirmation dialogs (`0 2px 4px rgba(15, 44, 89, 0.1)`). No visual element should appear disconnected from its structural parent.

## Shapes

The interface embraces an architectural, near-orthogonal profile:
- Base corner radius is **2px to 4px (`roundedness: 1`)**.
- Status tags (`AVL`, `RAC`, `WL`), train class badges (`1A`, `2A`, `3A`, `SL`, `CC`), and timetable cells utilize sharp **2px** radiused corners.
- Action buttons, standard text fields, and dropdown containers use **3px or 4px** corners maximum.
- **0px (Straight Angle):** Used for data table cells, segmented route timelines, and adjacent quota selection buttons to create solid, seamless utility ribbons. Circular (pill) geometry is completely forbidden.

## Components

### 1. Buttons
- **Primary Action (Search Trains, Book Now):** Solid deep crimson (`#B91C1C`) or deep navy (`#0F2C59`), white text, 4px radius, uppercase `label-lg`, 36px height (compact: 32px), zero shadow, sharp active press state (`#7F1D1D` or `#081A35`).
- **Secondary / Filter Buttons:** Solid white background, `#0F2C59` text, 1px `#CBD5E1` border, hover fill `#F1F5F9`.
- **Segmented Quota Selectors (GN, TQ, PT, LD, SS):** Contiguous grouped buttons with 1px border dividers; active tab has `#0F2C59` fill with white bold text.

### 2. Search & Form Inputs
- **Station Selector Fields:** 38px height, 1px solid `#94A3B8` border. Label pinned inside top-left or standard stacked label. Displays station name followed by tabular bold code in parentheses (e.g., `NEW DELHI (NDLS)`).
- **Date & Class Selectors:** Native-styled crisp date picker inputs with trailing calendar glyphs. Immediate keyboard-input support (`DD/MM/YYYY`).
- **Swapper Control:** Compact square button (`32x32px`) centered between Origin and Destination fields with opposing directional arrows (`⇄`).

### 3. Status Badges & Class Tiles
- **Availability Cells:** Dense rectangular blocks (`width: 100px`, `height: 52px`) displaying Class (`3A`), Price (`₹1,250`), Status (`AVAILABLE-0042`), and update timestamp.
- **Status Typography Colors:**
  - `AVAILABLE`: `#15803D` background `#DCFCE7`, border `#86EFAC`.
  - `RAC [Seat No]`: `#B45309` background `#FEF3C7`, border `#FDE68A`.
  - `WL [Number]`: `#B91C1C` background `#FEE2E2`, border `#FECACA`.

### 4. Train Result Cards & Timetable Rows
- **Header:** Train Number and Name (`12952 / MUMBAI TEJAS RAJ`), Departure Time, Origin Station Code, Duration Bar with stop count, Arrival Time, Destination Station Code, and Running Days indicators (`M T W T F S S` with inactive days dimmed).
- **Collapsible Drawer:** Immediate access to complete route schedule matrix containing Columns: Stop #, Station Code, Station Name, Arrival, Departure, Halt Time, Distance (km), and Day.

### 5. Data Tables
- Header row `#0F2C59` with white uppercase text or `#E2E8F0` with `#1E293B` text. Alternating row striping (`#FFFFFF` and `#F8FAFC`). Thin 1px solid borders (`#CBD5E1`) separating cells. Monospaced numeric alignments to the right; text left-aligned.